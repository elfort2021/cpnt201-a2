# cpnt201-a2 
## Eleanor Forte, 000841873 

Github Repo: 
https://github.com/elfort2021/cpnt201-a2
Github Pages: 
https://elfort2021.github.io/cpnt201-a2/




### Shoutouts 
As always, the cry club!! 
Kyle, Erica, Karen, and new members Jess and Isha 
Wooooo. 




## Attributions:


**Images** 
Photo by Richard Lee on Unsplash (Smol Brown Angry)
https://unsplash.com/photos/8spo0Sr00j8


Photo by Robin Canfield on Unsplash (3 Angry Birds)
https://unsplash.com/photos/MUwy-9TLUg0

Photo by Dominik VO on Unsplash (Confused Owl)
https://unsplash.com/photos/lNeIjS1rXus 

**Code** 
Tony G! From: 
https://sait-wbdv.github.io/sample-code/frontend/image-performance/srcset/
